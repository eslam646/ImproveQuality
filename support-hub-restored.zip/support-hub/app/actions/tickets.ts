"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { canManage, requirePerm, requireStaff } from "@/lib/auth";
import {
  addNoteOp, assignDeveloperOp, assignTesterOp, changeStatusOp, createTicketOp,
  declineAssignmentOp, setEstimationOp,
} from "@/lib/ops";
import { getRepo } from "@/lib/db";
import type { DevStatus } from "@/lib/types";
import { allowedTransitions, NOTE_REQUIRED_STATUSES, ROLE_LABELS } from "@/lib/labels";

function enc(msg: string) { return encodeURIComponent(msg); }
// التقاط الأخطاء غير المتوقعة وعرضها برسالة بدل خطأ 500 — وأيضاً تكشف سبب أي فشل فعلي
function failMsg(e: unknown): string { const m = e instanceof Error ? e.message : String(e); return m.slice(0, 140); }
const labelOf = (a: { name: string; role: keyof typeof ROLE_LABELS }) => `${a.name} (${ROLE_LABELS[a.role]})`;

function estFromForm(formData: FormData) {
  const d = parseFloat(String(formData.get("est_days") ?? ""));
  const h = parseFloat(String(formData.get("est_hours") ?? ""));
  return {
    days: Number.isFinite(d) && d >= 0 ? d : null,
    hours: Number.isFinite(h) && h >= 0 ? h : null,
  };
}

// ═══ إنشاء طلب (داخلي) ═══
export async function createTicketAction(formData: FormData) {
  const actor = await requirePerm("new_ticket");
  const repo = await getRepo();
  const settings = await repo.settingsGet();
  const cfg = settings.form_fields;
  const show = (k: string) => cfg.find((f) => f.key === k)?.visible ?? true;
  const need = (k: string) => show(k) && (cfg.find((f) => f.key === k)?.required ?? false);

  const client_id = String(formData.get("client_id") ?? "").trim();
  let client_name = String(formData.get("client_name") ?? "").trim();
  if (client_id) {
    const c = (await repo.clientsList()).find((x) => x.id === client_id);
    if (c) {
      client_name = c.name;
      if (c.contact_email && !String(formData.get("client_contact") ?? "").trim()) {
        formData.set("client_contact", c.contact_email);
      }
    }
  }
  const client_contact = String(formData.get("client_contact") ?? "").trim();
  const details = String(formData.get("details") ?? "").trim();
  const developer_id = String(formData.get("developer_id") ?? "").trim();
  const tester_id = String(formData.get("tester_id") ?? "").trim();
  const creator_id = String(formData.get("creator_id") ?? "").trim() || actor.id;

  const fail = (msg: string): never => redirect(`/tickets/new?err=${enc(msg)}`);
  if (need("client") && !client_id && client_name.length < 2) fail("اسم العميل إجباري — اختر من القائمة أو اكتبه");
  if (need("client_contact") && !client_contact) fail("وسيلة تواصل العميل إجبارية");
  if (need("details") && details.length < 5) fail("اكتب تفاصيل كافية للطلب (5 أحرف على الأقل)");
  if (need("developer") && !developer_id) fail("إسناد المطور إجباري");
  if (client_name.length < 2) fail("اختر العميل من القائمة أو اكتب اسمه");
  if (details.length < 5) fail("اكتب تفاصيل كافية للطلب");
  // القاعدة الذهبية: لا مطوّر قبل المختبِر أولاً
  if (developer_id && !tester_id) fail("حدّد فريق الاختبار أولاً — لا يُسنَد المطوّر إلا بعد التيست");

  // الحقول المخصصة الظاهرة في النموذج الداخلي (cf_<key>) — مع تحقق الإجبارية
  const custom: Record<string, string> = {};
  for (const cf of settings.custom_fields.filter((f) => f.internal)) {
    const v = String(formData.get(`cf_${cf.key}`) ?? "").trim().slice(0, 500);
    if (cf.required && !v) fail(`حقل «${cf.label}» إجباري`);
    if (v && cf.type === "file" && !/^[^|]{1,100}\|(https?:\/\/|local:\/\/)/.test(v)) {
      fail(`حقل «${cf.label}»: تعذر قبول الملف — أعد رفعه`);
    }
    if (v) custom[cf.key] = v;
  }

  const creator = (await repo.staffGet(creator_id)) ?? actor;
  const label = creator.id === actor.id ? creator.name : `${creator.name} (أدخله ${actor.name})`;
  const ticket = await createTicketOp({
    client_name, client_contact: client_contact || null, details,
    developer_id: developer_id || null,
    tester_id: tester_id || null,
    is_urgent: formData.get("is_urgent") === "1",
    actor: { staff_id: creator.id, label }, source: "internal",
    custom_data: custom,
  });
  revalidatePath("/dashboard");
  redirect(`/tickets/${ticket.code}?created=1`);
}

// ═══ إسناد التيست (أولاً دائماً) + تقدير التنفيذ ═══
export async function assignTesterAction(formData: FormData) {
  const actor = await requireStaff(["admin", "support"]);
  const code = String(formData.get("code") ?? "");
  const testerId = String(formData.get("tester_id") ?? "");
  const repo = await getRepo();
  const t = await repo.ticketByCode(code);
  try {
    if (t && testerId) await assignTesterOp(t.id, testerId, labelOf(actor), estFromForm(formData));
  } catch (e) {
    redirect(`/tickets/${code}?err=${enc(`تعذر إسناد التيست: ${failMsg(e)}`)}`);
  }
  revalidatePath(`/tickets/${code}`);
  redirect(`/tickets/${code}?ok=${enc("تم تعيين فريق الاختبار وإرسال الإشعارات ✓")}`);
}

// ═══ إسناد المطوّر — مسموح بعد تعيين التيست فقط ═══
export async function assignDeveloperAction(formData: FormData) {
  const actor = await requireStaff();
  const code = String(formData.get("code") ?? "");
  const developerId = String(formData.get("developer_id") ?? "");
  const repo = await getRepo();
  const t = await repo.ticketByCode(code);
  if (!t) redirect("/dashboard");

  // من يسند؟ الإدارة/الدعم — أو التيست المسند نفسه (يستلم ثم يسلّم للديف)
  const isManager = actor.role === "admin" || actor.role === "support";
  const isAssignedTester = actor.role === "tester" && t.tester_id === actor.id;
  if (!isManager && !isAssignedTester) {
    redirect(`/tickets/${code}?err=${enc("إسناد المطور من صلاحية الإدارة أو التيست المسند فقط")}`);
  }
  // القاعدة الذهبية: لا مطوّر قبل المختبِر أولاً
  if (!t.tester_id) {
    redirect(`/tickets/${code}?err=${enc("حدّد فريق الاختبار أولاً — لا يُسنَد المطوّر إلا بعد التيست")}`);
  }
  try {
    if (developerId) await assignDeveloperOp(t.id, developerId, labelOf(actor), estFromForm(formData));
  } catch (e) {
    redirect(`/tickets/${code}?err=${enc(`تعذر إسناد المطور: ${failMsg(e)}`)}`);
  }
  revalidatePath(`/tickets/${code}`);
  redirect(`/tickets/${code}?ok=${enc("تم تعيين المطور وإرسال الإشعارات ✓")}`);
}

// ═══ الاعتذار عن المهمة (التيست/الديف) بسبب إجباري ═══
export async function declineAssignmentAction(formData: FormData) {
  const actor = await requireStaff(["tester", "developer"]);
  const code = String(formData.get("code") ?? "");
  const reason = String(formData.get("reason") ?? "").trim();
  const repo = await getRepo();
  const t = await repo.ticketByCode(code);
  if (!t) redirect("/dashboard");
  if (reason.length < 3) {
    redirect(`/tickets/${code}?err=${enc("سبب الاعتذار إجباري — اكتبه بوضوح ليصل لمدخل البيانات والإدارة")}`);
  }
  const r = await declineAssignmentOp(t.id, { staff_id: actor.id, name: actor.name, role: actor.role }, reason);
  revalidatePath(`/tickets/${code}`);
  redirect(`/tickets/${code}?${r.ok ? `ok=${enc("تم تسجيل اعتذارك وإبلاغ مدخل البيانات والإدارة ✓")}` : `err=${enc(r.error ?? "تعذر الاعتذار")}`}`);
}

// ═══ تحديث تقدير التنفيذ (ساعات/أيام) — يظهر في الطلب والاستعلام ═══
export async function setEstimationAction(formData: FormData) {
  await requireStaff(["admin", "support"]);
  const code = String(formData.get("code") ?? "");
  const repo = await getRepo();
  const t = await repo.ticketByCode(code);
  if (t) await setEstimationOp(t.id, estFromForm(formData));
  revalidatePath(`/tickets/${code}`);
  redirect(`/tickets/${code}?ok=${enc("تم تحديث تقدير التنفيذ ✓")}`);
}

// ═══ تغيير الحالة — بملاحظة إجبارية عند الرفض/فشل الاختبار ═══
export async function changeStatusAction(formData: FormData) {
  const actor = await requireStaff();
  const code = String(formData.get("code") ?? "");
  const status = String(formData.get("dev_status") ?? "") as DevStatus;
  const note = String(formData.get("note") ?? "");
  const repo = await getRepo();
  const t = await repo.ticketByCode(code);
  if (!t) redirect("/dashboard");
  const allowed = allowedTransitions(actor.role, t.dev_status);
  if (!allowed.includes(status)) {
    redirect(`/tickets/${code}?err=${enc("غير مصرح لك بهذا التحويل")}`);
  }
  if (NOTE_REQUIRED_STATUSES.includes(status) && note.trim().length < 3) {
    const what = status === "rejected" ? "سبب الرفض" : "سبب فشل الاختبار / المشكلة للمطور";
    redirect(`/tickets/${code}?err=${enc(`${what} إجباري — يُرسل في الإيميل`)}`);
  }
  await changeStatusOp(t.id, status, labelOf(actor), note || undefined);
  revalidatePath(`/tickets/${code}`);
  redirect(`/tickets/${code}?ok=${enc("تم تحديث الحالة وإطلاق الإشعارات ✓")}`);
}

// ═══ نتيجة الاختبار من واجهة الاختبار ═══
export async function testerResultAction(formData: FormData) {
  const actor = await requireStaff(["tester", "admin"]);
  const code = String(formData.get("code") ?? "");
  const result = String(formData.get("result") ?? "") as DevStatus;
  const note = String(formData.get("note") ?? "").trim();
  const repo = await getRepo();
  const t = await repo.ticketByCode(code);
  if (!t) redirect("/testing");
  if (t.dev_status !== "ready_for_test" || !["test_passed", "test_failed"].includes(result)) {
    redirect(`/testing?err=${enc("هذه التذكرة ليست في انتظار الاختبار")}`);
  }
  if (result === "test_failed" && note.length < 3) {
    redirect(`/testing?err=${enc("اكتب سبب فشل الاختبار / وصف المشكلة — يُرسل للمطوّر إجبارياً")}`);
  }
  await changeStatusOp(t.id, result, labelOf(actor), note || undefined);
  revalidatePath("/testing");
  redirect(`/testing?ok=${enc(result === "test_passed" ? "تم اعتماد التذكرة ✓" : "سُجل فشل الاختبار وأُبلغ المطور بالسبب ✓")}`);
}

// ═══ ملاحظة/رد — مفتوح لكل أطراف الطلب (مدخل بيانات ↔ التيست ↔ الديف ↔ الإدارة) ═══
export async function addNoteAction(formData: FormData) {
  const actor = await requireStaff();
  const code = String(formData.get("code") ?? "");
  const note = String(formData.get("note") ?? "").trim();
  const repo = await getRepo();
  const t = await repo.ticketByCode(code);
  if (t && note.length >= 2) await addNoteOp(t.id, note, labelOf(actor), actor.role, actor.id);
  revalidatePath(`/tickets/${code}`);
  redirect(`/tickets/${code}?ok=${enc("أُضيفت ملاحظتك وأُرسلت لكل أطراف الطلب ✓")}`);
}

export async function canManageGuard() {
  const actor = await requireStaff();
  return canManage(actor);
}
